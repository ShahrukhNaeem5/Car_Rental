document.addEventListener('DOMContentLoaded', function() {
    var dateInputs = document.querySelectorAll('.date-input-wrapper input[type="date"]');

    // Function to add event listeners to time inputs
    

    // Function to add event listeners to date inputs
    dateInputs.forEach(function(input) {
        input.addEventListener('input', function() {
            // Update the input field with the selected date
            input.nextElementSibling.textContent = input.value;
        });
    });
});

document.addEventListener('DOMContentLoaded', function() {
    var timeInputs = document.querySelectorAll('.time-input-wrapper input[type="time"]');
    
    // Function to format time display with AM/PM
    function formatTimeWithAMPM(time) {
        var timeParts = time.split(':');
        var hours = parseInt(timeParts[0], 10);
        var minutes = timeParts[1];
        
        if (hours >= 12) {
            return (hours === 12 ? '12' : (hours - 12)) + ':' + minutes + ' PM';
        } else {
            return (hours === 0 ? '12' : hours) + ':' + minutes + ' AM';
        }
    }

    // Function to update time display with AM/PM
    function updateDisplayTime(input) {
        var value = input.value;
        input.nextElementSibling.textContent = formatTimeWithAMPM(value);
    }

    // Add event listeners to time inputs
    timeInputs.forEach(function(input) {
        input.addEventListener('input', function() {
            updateDisplayTime(input);
        });
    });
});


var swiper = new Swiper(".mySwiper", {
    slidesPerView: 1,
    grabCursor: true,
    loop: true,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
});

